package com.boa.counterpartyapi.models;

public enum Gender {
MALE,FEMALE,TRANSGENDER
}
