package com.boa.bankprocess.delegates;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.stereotype.Component;
@Component("tradeOptopnDelegate")
public class TradeOptionDelegate implements JavaDelegate{

	@Override
	public void execute(DelegateExecution execution) throws Exception {
		// TODO Auto-generated method stub
		String option=execution.getVariable("tradeOption").toString();
		boolean status=false;
		if(option.equals("Economic"))
			status=true;
		execution.setVariable("status", status);
		
		
	}

}
