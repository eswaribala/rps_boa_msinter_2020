package com.boa.customer.services;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.boa.customer.models.Customer;
import com.boa.customer.models.FullName;
import com.boa.customer.models.GenderType;
import com.boa.customer.repositories.CustomerRepository;


@Service
public class CustomerService {
	@Autowired
	private CustomerRepository customerRepository;
	
	//insert
	public Customer addCustomer(Customer customer)
	{
		return customerRepository.save(customer);
	}
	
	//select all
	public List<Customer> getAllCustomers()
	{
		return this.customerRepository.findAll();
	}
	
	//get customer by id
	
	public Customer getCustomerById(long customerId)
	{
		return this.customerRepository.findById(customerId).orElse(null);
	}
	
	//delete the customer
	
	public boolean deleteCustomerById(long customerId)
	{
		 boolean status=true;
		 this.customerRepository.deleteById(customerId);
		 if(getCustomerById(customerId)!=null)
			 status=false;
		 return status;
			  
	}
	
	//must pass customerId
	
	public Customer updateCustomer(Customer customer)
	{
		return this.customerRepository.save(customer);
	}
	

	 @Transactional
	    public Customer createCustomer(final String firstName, final String lastName,final String emailId, final long mobileNo , final String dob, final String gender) {
	        final FullName fullName=new FullName();
	        fullName.setFirstName(firstName);
	        fullName.setLastName(lastName);
	        fullName.setMiddleName(null);
		    final Customer customer = new Customer();
	        customer.setName(fullName);
	        customer.setEmailId(emailId);
	        customer.setMobileNo(mobileNo);
	        customer.setGender(GenderType.valueOf(gender));
	        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
	       
	        //convert String to LocalDate
	        LocalDate localDate = LocalDate.parse(dob, formatter);
	        customer.setDob(localDate);
	        return this.customerRepository.save(customer);
	    }

}
