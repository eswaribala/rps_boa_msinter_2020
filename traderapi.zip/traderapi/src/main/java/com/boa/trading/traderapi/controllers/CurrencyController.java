package com.boa.trading.traderapi.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.boa.trading.traderapi.models.Currency;
import com.boa.trading.traderapi.services.CurrencyService;

@RestController
@RequestMapping("/currencies")
public class CurrencyController {
	@Autowired
	private CurrencyService currencyService;
	
	//add currency
	@PostMapping({"/v1.0", "/v1.1"})
	public ResponseEntity<?> addCurrency(@RequestBody Currency currency)
	{
		Currency currencyObj=this.currencyService.addCurrency(currency);
		if(currencyObj!=null)
		{
			return ResponseEntity.status(HttpStatus.ACCEPTED).body(currencyObj);
			
		}
		else
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Currency not created validate the input");
		
		
	}
	@GetMapping({"/v1.0", "/v1.1"})
	public List<Currency> getAllCurrencies()
	{
		return this.currencyService.selectAllCurrencies();
	}
	
	@GetMapping({"/v1.0/{code}", "/v1.1/{code}"})
	public ResponseEntity<?> getCurrencyById(@PathVariable("code") String code)
	{
		Currency currency=this.currencyService.selectCurrencyById(code);
		if(currency!=null)
		{
			return ResponseEntity.status(HttpStatus.ACCEPTED).body(currency);
			
		}
		else
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Currency Record not found");
					
	}
	
	@DeleteMapping({"/v1.0/{code}", "/v1.1/{code}"})
	public ResponseEntity<?> deleteCurrency(@PathVariable("code") String code)
	{
		boolean status=this.currencyService.deleteCurrency(code);
		if(status)
		{
			return ResponseEntity.status(HttpStatus.ACCEPTED).body(code+"deleted...");
			
		}
		else
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Code Not Existing, not deleted");
	}
	
	
	//update currency
		@PutMapping({"/v1.0", "/v1.1"})
		public ResponseEntity<?> updateCurrency(@RequestBody Currency currency)
		{
			Currency currencyObj=this.currencyService.updateCurrency(currency);
			if(currencyObj!=null)
			{
				return ResponseEntity.status(HttpStatus.ACCEPTED).body(currencyObj);
				
			}
			else
				return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Currency not created validate the input");
			
			
		}
	
	
	
	

}
