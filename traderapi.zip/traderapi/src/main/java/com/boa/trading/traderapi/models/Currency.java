package com.boa.trading.traderapi.models;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name="Trade_Currency")
@Data
public class Currency {
	@Id
	@Column(name="Code",length = 3)
	private String code;
	@Column(name="Symbol_Location",length = 150,nullable = false)
	private String symbolLocation;
	@Column(name="Tradeable_Flag",nullable = false)
	private Boolean tradeableFlag;
	@Column(name="Description",length = 150,nullable = false)
	private String description;	
	
	

}
