package com.boa.trading.traderapi.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.boa.trading.traderapi.models.Currency;

public interface CurrencyRepository extends JpaRepository<Currency,String>{

}
