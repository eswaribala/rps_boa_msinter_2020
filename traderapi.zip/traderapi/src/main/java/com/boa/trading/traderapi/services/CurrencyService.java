package com.boa.trading.traderapi.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.boa.trading.traderapi.models.Currency;
import com.boa.trading.traderapi.repositories.CurrencyRepository;

@Service
public class CurrencyService {
    @Autowired
	private CurrencyRepository  currencyRepository;
    
    //create
    public Currency addCurrency(Currency currency)
    {
    	return this.currencyRepository.save(currency);
    }
    
    
    //update
    
    public Currency updateCurrency(Currency currency)
    {
    	return this.currencyRepository.save(currency);
    }
    
    //delete
    public boolean deleteCurrency(String currencyCode)
    {
    	boolean status=false;
    	this.currencyRepository.deleteById(currencyCode);
    	if(this.selectCurrencyById(currencyCode)!=null)
    		status=true;
    	return status;
    	
    }
    
    //select all
    
    public List<Currency> selectAllCurrencies()
    {
    	return this.currencyRepository.findAll();
    	
    	
    }
    
    //select curr by code
    
    public Currency selectCurrencyById(String currencyCode)
    {
    	return this.currencyRepository.findById(currencyCode).orElse(null);
    	
    	
    }
    
}
