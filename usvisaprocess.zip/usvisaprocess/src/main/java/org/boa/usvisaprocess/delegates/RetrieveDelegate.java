package org.boa.usvisaprocess.delegates;

import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;

import org.boa.usvisaprocess.models.Flight;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.stereotype.Component;

@Component("retrieveDelegate")
public class RetrieveDelegate implements JavaDelegate{

	@Override
	public void execute(DelegateExecution execution) throws Exception {
		// TODO Auto-generated method stub
		String fromCity=execution.getVariable("fromCity").toString();
		String toCity=execution.getVariable("toCity").toString();
		Date date=(Date) execution.getVariable("travelDate");	     
		LocalDate travelDate=Instant.ofEpochMilli(date.getTime())
				.atZone(ZoneId.systemDefault()).toLocalDate();
		//travelDate.plusMonths(1);
		List<Flight> filteredFlights=new ArrayList<Flight>();
		for(Flight flight:getAvailableFlights())
		{
			flight.getDot().plusMonths(1);
			System.out.println(flight.getDot()+"-->"+travelDate);
			if((flight.getFromCity().equals(fromCity))
					&&(flight.getToCity().contentEquals(toCity))
					&&(flight.getDot().isEqual(travelDate))
					)
					{
				           filteredFlights.add(flight);
					}
		}
		
		System.out.println("Filtered Flight Size="+filteredFlights.size());
		execution.setVariable("availableFlightCount", filteredFlights.size());
		
	}
	
	
	private List<Flight>getAvailableFlights()
	{
	  List<Flight> flightList=new ArrayList<Flight>();
	  for(int i=0;i<100;i++)
	  {
		  flightList.add(new Flight("fromCity"+i,
				  "toCity"+i,
				  LocalDate.of(2020, new Random().nextInt(10)+1, new Random().nextInt(29)+1)));
	  }
	  flightList.add(new Flight("Chennai","Delhi",LocalDate.now()));	
		
	  return flightList;
	}

}
