package com.virtusa.kafkaappointmentproducer.models;

public enum AppointmentType {
  Loan,KYC,Savings,Demat
}
