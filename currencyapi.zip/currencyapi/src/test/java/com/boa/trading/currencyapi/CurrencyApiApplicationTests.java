package com.boa.trading.currencyapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CurrencyApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
