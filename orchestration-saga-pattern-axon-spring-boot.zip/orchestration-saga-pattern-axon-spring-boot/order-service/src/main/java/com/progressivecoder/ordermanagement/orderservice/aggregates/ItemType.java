package com.progressivecoder.ordermanagement.orderservice.aggregates;

public enum ItemType {

    LAPTOP, HEADPHONE, SMARTPHONE
}
